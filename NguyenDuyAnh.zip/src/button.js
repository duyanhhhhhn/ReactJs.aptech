// import styles from './Button.module.css';
// function Button(props) {
  // var bgColor;
  // switch (props.type) {
  //   case 'primary': bgColor='#0d6efd'; break;
  //   case 'success': bgColor='#198754'; break;
  //   case 'danger': bgColor='#dc3545'; break;
  // }
  // return (
  //     <button style={{ backgroundColor: bgColor }}
  //       className={styles.btn}>
  //       {props.children}
  //     </button>
  // );
//   let color, style;
//   switch (props.type) {
//     case 'primary': color='#0d6efd'; break;
//     case 'success': color='#198754'; break;
//     case 'danger': color = '#dc3545'; break;
//     case 'warning': color = '#ffc107'; break;
//   }
//   if (props.outline) {
//     style = { color: color, borderColor: color, backgroundColor: 'white' };
//   }
//   else {
//     style = { color: 'white', backgroundColor: color }
//   }
//   return (
//       <button style={style}
//         className={styles.btn}>
//         {props.children}
//       </button>
//   );

// import { useState } from "react";


// }
// function Button(props) {
  // const handleClick = (x) => {
  //   alert(`Hello,My name is ${x}`);
  // }
  // return (
  //   <>
  //     <button onClick={() => handleClick('Anh')}>{props.children }</button>
  //   </>
  // )
// }
// export default Button;
// const Button = (props) => {
//   const [name, setName] = useState("Duy Anh");
//   const [age, setAge] = useState(18)
//   const handleClick = () => {
//     setName("Hoang");
//     setAge(" 24");
//   }
//   return (
//     <>
//       Ten: {name}, tuoi {age }<br />
//       <button onClick={handleClick}>Change</button>
//     </>
//     );
// }
 
// export default Button;