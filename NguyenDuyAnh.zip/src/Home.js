const Home = () => {
    return (<>
    <h1>Chào mừng đến với trang web</h1>
    </>);
}
 
export default Home;